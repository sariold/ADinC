#ifndef SCANNER_H
#define SCANNER_H

#define MAXINPUT 100  /* maximal length of the input */

char *readInput();

#endif
